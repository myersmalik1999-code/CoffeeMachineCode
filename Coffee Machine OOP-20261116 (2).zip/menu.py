
class MenuItem:
    def __init__(self, name, cost, ingredients):
        self.name = name
        self.cost = cost
        self.ingredients = ingredients


class Menu:
    def __init__(self):
        self.menu = [
            MenuItem("latte", 2.5, {"water": 200, "milk": 150, "coffee": 24}),
            MenuItem("espresso", 1.5, {"water": 50, "coffee": 18}),
            MenuItem("cappuccino", 3.0, {"water": 250, "milk": 100, "coffee": 24})
        ]

    def get_items(self):
        items = ""
        for drink in self.menu:
            items += drink.name + "/"
        return items.rstrip("/")

    def find_drink(self, order_name):
        for drink in self.menu:
            if drink.name == order_name:
                return drink
        return None
